#include <iostream>
using namespace std;

/*****************************************************
 * Compléter le code à partir d'ici
 *****************************************************/
class Patient
{
	private:
		double patientMasse;
		double patientHauteur;
	public:
		void init(double poids, double taille)
		{
			if(poids > 0 && taille > 0)
			{
				patientMasse = poids;
				patientHauteur = taille;
			}
			else
			{
				patientMasse = 0.0;
				patientHauteur = 0.0;
			}
		};
		void afficher()
		{
			cout << "Patient : " << patientMasse << " kg pour " << patientHauteur << " m" << endl;
		};
		double poids() const{ return patientMasse; };
		double taille() const{ return patientHauteur; };
		double imc()
		{
			if(patientHauteur == 0.0) return 0.0;
			else
			{
				return patientMasse / (patientHauteur * patientHauteur);
			}
		};
};

/*******************************************
 * Ne rien modifier après cette ligne.
 *******************************************/

int main()
{
  Patient quidam;
  double poids, taille;
  do {
    cout << "Entrez un poids (kg) et une taille (m) : ";
    cin >> poids >> taille;
    quidam.init(poids, taille);
    quidam.afficher();
    cout << "IMC : " << quidam.imc() << endl;
  } while (poids * taille != 0.0);
  return 0;
}

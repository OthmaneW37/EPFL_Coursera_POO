#include <iostream>
using namespace std;

/*******************************************
 * Complétez le programme à partir d'ici.
 *******************************************/
class Tirelire
{
	private:
		double tirelireMontant;
	public:
		double getMontant() const{ return tirelireMontant; };
		void afficher()
		{
			if(tirelireMontant == 0.0) cout << "Vous etes sans le sou." << endl;
			else cout << "Vous avez : " << tirelireMontant << " euros dans votre tirelire." << endl;
		};
		void secouer()
		{
			if(tirelireMontant > 0) cout << "Bing bing" << endl;
		};
		void remplir(double argentAjoute)
		{
			if(argentAjoute > 0) tirelireMontant += argentAjoute;
		};
		void vider(){ tirelireMontant = 0.0; };
		void puiser(double montantPuise)
		{
			if(montantPuise > tirelireMontant) vider();
			else if(montantPuise <= tirelireMontant && montantPuise > 0) tirelireMontant -= montantPuise; 
		};
		bool montant_suffisant(double vacancesBudget, double& vacancesSolde)
		{
			if(vacancesBudget <= 0)
			{
				vacancesSolde = tirelireMontant;
				return true;
			}
			else
			{
				if(vacancesBudget <= tirelireMontant)
				{
					vacancesSolde = tirelireMontant - vacancesBudget;
					return true; 
				}
				else
				{
					vacancesSolde = vacancesBudget - tirelireMontant;
					return false;
				}
			}
		};
		double calculerSolde(double vacancesBudget)
		{
			if(vacancesBudget <= 0) return tirelireMontant;
			else return (tirelireMontant - vacancesBudget);
		};
};
/*******************************************
 * Ne rien modifier après cette ligne.
 *******************************************/

int main()
{
  Tirelire piggy;

  piggy.vider();
  piggy.secouer();
  piggy.afficher();

  piggy.puiser(20.0);
  piggy.secouer();
  piggy.afficher();

  piggy.remplir(550.0);
  piggy.secouer();
  piggy.afficher();

  piggy.puiser(10.0);
  piggy.puiser(5.0);
  piggy.afficher();

  cout << endl;

  // le vacancesBudget de vos vacances de rève.
  double vacancesBudget;

  cout << "Donnez le vacancesBudget de vos vacances : ";
  cin >> vacancesBudget;

  // ce qui resterait dans la tirelire après les
  // vacances
  double vacancesSolde(0.0);

  if (piggy.montant_suffisant(vacancesBudget, vacancesSolde)) {
    cout << "Vous êtes assez riche pour partir en vacances !"
         << endl
         << "Il vous restera " << vacancesSolde << " euros"
         << " à la rentrée." << endl << endl;
    piggy.puiser(vacancesBudget);
  } else {
    cout << "Il vous manque " << vacancesSolde << " euros"
         << " pour partir en vacances !" << endl << endl;
  }
  return 0;
}
